package com.example.celllab

import android.animation.ObjectAnimator
import android.app.Activity
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.Intent
import android.content.res.ColorStateList
import android.graphics.Color
import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.media.projection.MediaProjectionManager
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.text.InputType
import android.view.Gravity
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.inputmethod.InputMethodManager
import android.widget.*
import org.json.JSONArray
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

class MainActivity : Activity() {
    private val main = Handler(Looper.getMainLooper())
    private val io = Executors.newSingleThreadExecutor()
    private val prefs by lazy { getSharedPreferences("cfg", Context.MODE_PRIVATE) }
    private val REQ_CAPTURE = 1

    private lateinit var keyField: EditText
    private lateinit var modelField: EditText
    private lateinit var descField: EditText
    private lateinit var goBtn: Button
    private lateinit var controls: LinearLayout
    private lateinit var status: TextView
    private lateinit var progressText: TextView
    private lateinit var progress: ProgressBar
    private lateinit var result: LinearLayout

    private var plan: Plan? = null
    private var pos = 0
    private var renderedRaw = ""
    private val cardViews = ArrayList<View>()
    private val titleViews = ArrayList<TextView>()
    private val badgeViews = ArrayList<TextView>()
    private var pulseAnim: ObjectAnimator? = null

    private val GREEN = Color.rgb(46, 204, 113)
    private val CARD = Color.rgb(24, 30, 40)

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))

    private fun rounded(fill: Int, r: Int, stroke: Int = 0, sw: Int = 0): GradientDrawable =
        GradientDrawable().apply {
            setColor(fill)
            cornerRadius = dp(r).toFloat()
            if (sw > 0) setStroke(dp(sw), stroke)
        }

    private fun lp(top: Int = 0): LinearLayout.LayoutParams =
        LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT)
            .apply { topMargin = dp(top) }

    private fun field(hintText: String, lines: Int = 1): EditText = EditText(this).apply {
        hint = hintText
        setHintTextColor(Color.argb(110, 255, 255, 255))
        setTextColor(Color.WHITE)
        background = rounded(Color.rgb(27, 33, 44), 12, Color.argb(60, 255, 255, 255), 1)
        setPadding(dp(14), dp(12), dp(14), dp(12))
        if (lines > 1) {
            minLines = lines
            gravity = Gravity.TOP
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_FLAG_MULTI_LINE
        }
    }

    private fun button(label: String, fill: Int, fg: Int, stroke: Boolean = false, onClick: () -> Unit): Button =
        Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 15f
            typeface = Typeface.DEFAULT_BOLD
            setTextColor(fg)
            background = if (stroke) rounded(fill, 14, Color.argb(70, 255, 255, 255), 1) else rounded(fill, 14)
            setOnClickListener { onClick() }
        }

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.statusBarColor = Color.rgb(15, 19, 26)
        val scroll = ScrollView(this).apply { setBackgroundColor(Color.rgb(15, 19, 26)) }
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(18), dp(36), dp(18), dp(40))
        }
        scroll.addView(col)

        col.addView(TextView(this).apply {
            text = "🧬 Cell Lab помощник"
            textSize = 26f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        })
        col.addView(TextView(this).apply {
            text = "Опиши существо — получишь план. Потом запусти подсказки: приложение подсветит на экране игры, куда нажимать, и запомнит, на каком шаге ты остановился."
            textSize = 14f
            setTextColor(Color.argb(170, 255, 255, 255))
        }, lp(6))

        keyField = field("Ключ OpenRouter (sk-or-...)").apply {
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_PASSWORD
            setText(prefs.getString("key", ""))
        }
        modelField = field("Модель").apply { setText(prefs.getString("model", "openrouter/auto")) }
        descField = field("Например: быстрый хищник, который ест мелких клеток и умеет плавать", 4)
        col.addView(keyField, lp(18))
        col.addView(modelField, lp(10))
        col.addView(descField, lp(10))

        goBtn = button("Составить план", GREEN, Color.rgb(10, 25, 15)) { generate() }
        col.addView(goBtn, lp(14))

        status = TextView(this).apply {
            textSize = 14f
            gravity = Gravity.CENTER
            setTextColor(Color.argb(210, 255, 255, 255))
            visibility = View.GONE
        }
        col.addView(status, lp(14))

        controls = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            visibility = View.GONE
        }
        controls.addView(button("▶ Запустить подсказки в игре", Color.rgb(30, 90, 60), Color.WHITE, true) { startOverlay() }, lp(0))
        controls.addView(button("■ Остановить подсказки", Color.rgb(38, 46, 60), Color.WHITE, true) {
            stopService(Intent(this, OverlayService::class.java))
        }, lp(8))
        controls.addView(button("Скопировать план", Color.rgb(38, 46, 60), Color.WHITE, true) { copyGuide() }, lp(8))
        controls.addView(button("Новое существо", Color.rgb(60, 32, 36), Color.WHITE, true) { resetAll() }, lp(8))
        col.addView(controls, lp(14))

        progressText = TextView(this).apply {
            textSize = 13f
            setTextColor(Color.argb(180, 255, 255, 255))
            visibility = View.GONE
        }
        col.addView(progressText, lp(18))
        progress = ProgressBar(this, null, android.R.attr.progressBarStyleHorizontal).apply {
            progressTintList = ColorStateList.valueOf(GREEN)
            progressBackgroundTintList = ColorStateList.valueOf(Color.argb(50, 255, 255, 255))
            visibility = View.GONE
        }
        col.addView(progress, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, dp(8)).apply { topMargin = dp(6) })

        result = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        col.addView(result, lp(8))

        setContentView(scroll)
    }

    override fun onResume() {
        super.onResume()
        loadPlan()
    }

    /** Память: план и прогресс лежат в SharedPreferences, пока существо не достроено или не сброшено. */
    private fun loadPlan() {
        val raw = prefs.getString("plan", "") ?: ""
        if (raw.isEmpty()) {
            plan = null; renderedRaw = ""; pos = 0
            render()
            return
        }
        if (raw != renderedRaw) {
            plan = PlanStore.parse(raw)
            renderedRaw = raw
            pos = prefs.getInt("pos", 0).coerceIn(0, plan?.flat?.size ?: 0)
            render()
        } else {
            pos = prefs.getInt("pos", 0).coerceIn(0, plan?.flat?.size ?: 0)
            refreshStates()
        }
    }

    // ---------- запрос плана ----------
    private fun generate() {
        val key = keyField.text.toString().trim()
        val desc = descField.text.toString().trim()
        if (key.isEmpty()) { showStatus("Вставь ключ OpenRouter"); return }
        if (desc.isEmpty()) { showStatus("Опиши, какое существо нужно"); return }
        val model = modelField.text.toString().trim().ifEmpty { "openrouter/auto" }
        prefs.edit().putString("key", key).putString("model", model).apply()
        (getSystemService(INPUT_METHOD_SERVICE) as InputMethodManager).hideSoftInputFromWindow(descField.windowToken, 0)
        goBtn.isEnabled = false
        startLoading()
        io.execute {
            val raw = try { ask(key, model, desc) } catch (e: Exception) { "ERR:" + e.message }
            main.post { onResult(raw) }
        }
    }

    private fun startLoading() {
        status.text = "Составляю план…"
        status.visibility = View.VISIBLE
        pulseAnim?.cancel()
        pulseAnim = ObjectAnimator.ofFloat(status, "alpha", 1f, 0.3f).apply {
            duration = 700
            repeatCount = ObjectAnimator.INFINITE
            repeatMode = ObjectAnimator.REVERSE
            start()
        }
    }

    private fun stopLoading() {
        pulseAnim?.cancel()
        status.alpha = 1f
    }

    private fun showStatus(msg: String) {
        stopLoading()
        status.text = msg
        status.visibility = View.VISIBLE
    }

    private fun onResult(raw: String) {
        stopLoading()
        goBtn.isEnabled = true
        if (raw.startsWith("ERR:")) {
            showStatus("⚠ " + raw.removePrefix("ERR:").take(200))
            return
        }
        val obj = PlanStore.parseObj(raw)
        val parsed = if (obj != null) PlanStore.parse(obj.toString()) else null
        if (obj == null || parsed == null) {
            showStatus("Не получилось разобрать ответ. Попробуй ещё раз или выбери другую модель.")
            return
        }
        stopService(Intent(this, OverlayService::class.java))
        prefs.edit().putString("plan", obj.toString()).putInt("pos", 0).apply()
        status.visibility = View.GONE
        renderedRaw = ""
        loadPlan()
    }

    private fun ask(key: String, model: String, desc: String): String {
        val sys = "Ты эксперт по игре Cell Lab: Evolution Sandbox — песочнице, где игрок собирает организм в редакторе генома. " +
            "Пользователь описывает существо, которое хочет получить. Составь пошаговый план: что именно нажимать и какие значения выставлять в редакторе генома. " +
            "Что известно об игре: геном состоит из режимов (modes). У каждого режима выбирается тип клетки, например Phagocyte, Flagellocyte, Photocyte, Devorocyte, Lipocyte, Keratinocyte, Buoyocyte, Glueocyte, Virocyte, Stem Cell, Senseocyte, Myocyte, Neurocyte, Secrocyte, Stereocyte. " +
            "У режима есть настройки деления: соотношение масс, угол деления, интервал деления, режимы дочерних клеток Child A и Child B, адгезия (остаются ли дочерние клетки связанными), цвет. Один из режимов — начальный. " +
            "Опирайся только на то, что знаешь точно. Если не уверен в названии кнопки, настройки или в числе — опиши действие общими словами и поставь (?). Числа давай как стартовые значения и подсказывай, как их подстроить после теста. " +
            "Интерфейс игры английский. У каждого действия есть поле target — короткая надпись элемента интерфейса ровно так, как она написана в игре по-английски: по ней приложение найдёт элемент на экране и подсветит его. " +
            "В alt перечисли запасные варианты надписи. Если у элемента нет надписи (иконка, ползунок без подписи) — target пустая строка, а в text опиши, где он находится. Одно действие — одно нажатие или одна настройка. " +
            "Структура: сначала подготовка (новый геном), затем по одному шагу на каждый режим (в заголовке номер режима и роль, в cell — английское название типа клетки), в конце проверка в игре. Не больше 14 шагов, действия короткие, в повелительном наклонении. " +
            "Верни ТОЛЬКО JSON без пояснений: {\"name\":\"название существа\",\"idea\":\"как оно работает, 1–2 предложения\"," +
            "\"steps\":[{\"title\":\"Режим 1: роль\",\"cell\":\"Phagocyte\",\"actions\":[{\"text\":\"Нажми ...\",\"target\":\"Add mode\",\"alt\":[\"New mode\"]}]}],\"tips\":[\"...\"]}. Текст действий по-русски."
        val body = JSONObject()
            .put("model", model).put("max_tokens", 4000).put("temperature", 0.3)
            .put("messages", JSONArray()
                .put(JSONObject().put("role", "system").put("content", sys))
                .put(JSONObject().put("role", "user").put("content", desc)))
        val c = URL("https://openrouter.ai/api/v1/chat/completions").openConnection() as HttpURLConnection
        c.requestMethod = "POST"
        c.doOutput = true
        c.connectTimeout = 20000
        c.readTimeout = 120000
        c.setRequestProperty("Content-Type", "application/json")
        c.setRequestProperty("Authorization", "Bearer $key")
        c.outputStream.use { it.write(body.toString().toByteArray()) }
        val resp = (if (c.responseCode < 400) c.inputStream else c.errorStream).bufferedReader().readText()
        if (c.responseCode >= 400) return "ERR:API ${c.responseCode}: $resp".take(300)
        return JSONObject(resp).getJSONArray("choices").getJSONObject(0)
            .getJSONObject("message").getString("content")
    }

    // ---------- подсказки поверх игры ----------
    private fun startOverlay() {
        if (plan == null) { showStatus("Сначала составь план"); return }
        if (!Settings.canDrawOverlays(this)) {
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            Toast.makeText(this, "Дай разрешение «Поверх других окон» и нажми кнопку снова", Toast.LENGTH_LONG).show()
            return
        }
        val mpm = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        startActivityForResult(mpm.createScreenCaptureIntent(), REQ_CAPTURE)
    }

    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == REQ_CAPTURE && res == RESULT_OK && data != null) {
            val i = Intent(this, OverlayService::class.java).putExtra("code", res).putExtra("data", data)
            startForegroundService(i)
            moveTaskToBack(true)
        }
    }

    private fun resetAll() {
        stopService(Intent(this, OverlayService::class.java))
        prefs.edit().remove("plan").remove("pos").apply()
        descField.setText("")
        status.visibility = View.GONE
        renderedRaw = ""
        loadPlan()
    }

    // ---------- отображение ----------
    private fun render() {
        result.removeAllViews()
        cardViews.clear(); titleViews.clear(); badgeViews.clear()
        val p = plan
        if (p == null) {
            progress.visibility = View.GONE
            progressText.visibility = View.GONE
            controls.visibility = View.GONE
            return
        }
        controls.visibility = View.VISIBLE
        result.addView(TextView(this).apply {
            text = p.name
            textSize = 22f
            setTextColor(GREEN)
            typeface = Typeface.DEFAULT_BOLD
        })
        if (p.idea.isNotBlank()) {
            result.addView(TextView(this).apply {
                text = p.idea
                textSize = 14f
                setTextColor(Color.argb(210, 255, 255, 255))
            }, lp(4))
        }
        p.steps.forEachIndexed { i, s -> addCard(i, s) }
        if (p.tips.isNotEmpty()) {
            val box = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                background = rounded(Color.rgb(30, 36, 28), 16, withAlpha(GREEN, 90), 1)
                setPadding(dp(14), dp(12), dp(14), dp(14))
            }
            box.addView(TextView(this).apply {
                text = "💡 Советы"
                textSize = 15f
                setTextColor(Color.WHITE)
                typeface = Typeface.DEFAULT_BOLD
            })
            for (t in p.tips) {
                box.addView(TextView(this).apply {
                    text = "•  $t"
                    textSize = 14f
                    setTextColor(Color.argb(225, 255, 255, 255))
                }, lp(6))
            }
            result.addView(box, lp(14))
        }
        refreshStates()
    }

    private fun addCard(i: Int, s: Step) {
        val ac = cellAccent(s.cell)
        val card = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = rounded(CARD, 16, withAlpha(ac, 130), 1)
            setPadding(dp(14), dp(12), dp(14), dp(14))
        }
        val head = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val badge = TextView(this).apply {
            text = "${i + 1}"
            gravity = Gravity.CENTER
            setTextColor(Color.rgb(15, 19, 26))
            typeface = Typeface.DEFAULT_BOLD
            background = GradientDrawable().apply { shape = GradientDrawable.OVAL; setColor(ac) }
        }
        head.addView(badge, LinearLayout.LayoutParams(dp(32), dp(32)))
        val titleV = TextView(this).apply {
            text = s.title
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
            setPadding(dp(10), 0, 0, 0)
        }
        head.addView(titleV, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f))
        card.addView(head)
        if (s.cell.isNotBlank()) {
            card.addView(TextView(this).apply {
                text = s.cell
                textSize = 12f
                setTextColor(ac)
                background = rounded(withAlpha(ac, 40), 8)
                setPadding(dp(10), dp(3), dp(10), dp(3))
            }, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT)
                .apply { topMargin = dp(8) })
        }
        for (a in s.acts) {
            card.addView(TextView(this).apply {
                text = "•  ${a.text}"
                textSize = 14f
                setTextColor(Color.argb(230, 255, 255, 255))
            }, lp(6))
        }
        cardViews.add(card); titleViews.add(titleV); badgeViews.add(badge)
        // нажатие на карточку — «я на этом шаге»
        card.setOnClickListener {
            val p = plan
            if (p != null) {
                pos = p.firstPosOfStep(i)
                prefs.edit().putInt("pos", pos).apply()
                refreshStates()
            }
        }
        card.alpha = 0f
        card.translationY = dp(30).toFloat()
        result.addView(card, lp(10))
        card.animate().alpha(1f).translationY(0f).setStartDelay(i * 70L).setDuration(350)
            .setInterpolator(DecelerateInterpolator()).start()
    }

    private fun refreshStates() {
        val p = plan
        if (p == null) return
        val total = p.flat.size
        val cur = p.flat.getOrNull(pos)?.step ?: p.steps.size
        for (i in cardViews.indices) {
            val ac = cellAccent(p.steps[i].cell)
            val isDone = i < cur
            val isCur = i == cur
            cardViews[i].background = rounded(CARD, 16, withAlpha(ac, if (isCur) 255 else 130), if (isCur) 2 else 1)
            cardViews[i].animate().alpha(if (isDone) 0.5f else 1f).setDuration(200).start()
            val t = titleViews[i]
            val bd = badgeViews[i]
            if (isDone) {
                t.paintFlags = t.paintFlags or Paint.STRIKE_THRU_TEXT_FLAG
                bd.text = "✓"
            } else {
                t.paintFlags = t.paintFlags and Paint.STRIKE_THRU_TEXT_FLAG.inv()
                bd.text = "${i + 1}"
            }
        }
        progress.visibility = View.VISIBLE
        progressText.visibility = View.VISIBLE
        progress.max = total
        progress.setProgress(pos, true)
        progressText.text = "Выполнено $pos из $total действий"
        if (pos >= total && total > 0) {
            showStatus("🎉 Всё готово — существо собрано!")
        } else if (status.text.startsWith("🎉")) {
            status.visibility = View.GONE
        }
    }

    private fun copyGuide() {
        val p = plan ?: return
        val sb = StringBuilder()
        sb.append(p.name).append("\n")
        if (p.idea.isNotBlank()) sb.append(p.idea).append("\n")
        p.steps.forEachIndexed { i, s ->
            sb.append("\n${i + 1}. ${s.title}")
            if (s.cell.isNotBlank()) sb.append(" (${s.cell})")
            sb.append("\n")
            for (a in s.acts) sb.append("   - ").append(a.text).append("\n")
        }
        if (p.tips.isNotEmpty()) {
            sb.append("\nСоветы:\n")
            for (t in p.tips) sb.append("- ").append(t).append("\n")
        }
        val cm = getSystemService(CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("guide", sb.toString()))
        Toast.makeText(this, "Скопировано", Toast.LENGTH_SHORT).show()
    }
}
