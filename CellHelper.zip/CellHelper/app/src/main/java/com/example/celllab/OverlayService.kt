package com.example.celllab

import android.app.*
import android.content.Context
import android.content.Intent
import android.content.SharedPreferences
import android.content.pm.ServiceInfo
import android.graphics.*
import android.graphics.drawable.GradientDrawable
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import android.util.DisplayMetrics
import android.view.Display
import android.view.Gravity
import android.view.View
import android.view.WindowManager
import android.widget.LinearLayout
import android.widget.TextView
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import kotlin.math.abs

private class Line(val text: String, val box: Rect, val n: String)

class OverlayService : Service() {
    private val main = Handler(Looper.getMainLooper())
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private lateinit var tap: TapView
    private lateinit var panel: LinearLayout
    private lateinit var panelTitle: TextView
    private lateinit var panelText: TextView
    private lateinit var panelHint: TextView
    private lateinit var wm: WindowManager
    private lateinit var mlp: WindowManager.LayoutParams
    private lateinit var plp: WindowManager.LayoutParams
    private lateinit var prefs: SharedPreferences
    private val panelBg = GradientDrawable()

    private var plan: Plan? = null
    private var pos = 0
    private var curTargets: List<String> = emptyList()
    private var lines: List<Line> = emptyList()
    private var lastRect: RectF? = null
    private var miss = 0
    private var flipsLeft = 1
    private var panelTop = false
    private var accentColor = Color.rgb(46, 204, 113)
    private var realW = 0
    private var realH = 0
    @Volatile private var ocrBusy = false
    private var running = true

    private val GREEN = Color.rgb(46, 204, 113)

    override fun onBind(i: Intent?): IBinder? = null

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()
    private fun norm(s: String): String = s.lowercase().filter { it.isLetterOrDigit() }
    private fun withAlpha(c: Int, a: Int): Int = Color.argb(a, Color.red(c), Color.green(c), Color.blue(c))
    private fun rounded(fill: Int, r: Int): GradientDrawable =
        GradientDrawable().apply { setColor(fill); cornerRadius = dp(r).toFloat() }

    private fun realSize(): Pair<Int, Int> {
        val m = DisplayMetrics()
        val dmgr = getSystemService(DISPLAY_SERVICE) as DisplayManager
        @Suppress("DEPRECATION")
        dmgr.getDisplay(Display.DEFAULT_DISPLAY).getRealMetrics(m)
        return Pair(m.widthPixels, m.heightPixels)
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || ::tap.isInitialized) return START_NOT_STICKY
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        val ch = "cell"
        (getSystemService(NOTIFICATION_SERVICE) as NotificationManager)
            .createNotificationChannel(NotificationChannel(ch, "Cell Lab помощник", NotificationManager.IMPORTANCE_LOW))
        val notif = Notification.Builder(this, ch).setContentTitle("Cell Lab помощник подсказывает")
            .setSmallIcon(android.R.drawable.ic_menu_view).build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notif, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, notif)
        }

        prefs = getSharedPreferences("cfg", Context.MODE_PRIVATE)
        plan = PlanStore.load(prefs)
        if (plan == null) { stopSelf(); return START_NOT_STICKY }
        pos = prefs.getInt("pos", 0).coerceIn(0, plan!!.flat.size)

        val data = intent.getParcelableExtra<Intent>("data")!!
        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mpm.getMediaProjection(intent.getIntExtra("code", Activity.RESULT_OK), data)
        projection!!.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() { stopSelf() }
        }, main)

        val size = realSize()
        realW = size.first
        realH = size.second
        reader = ImageReader.newInstance(realW, realH, PixelFormat.RGBA_8888, 2)
        display = projection!!.createVirtualDisplay(
            "cap", realW, realH, resources.displayMetrics.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR, reader!!.surface, null, null
        )
        setupOverlay()
        refreshPanel()
        loop()
        return START_NOT_STICKY
    }

    // ---------- окна поверх игры ----------
    private fun pill(label: String, bg: Int, fg: Int, onClick: () -> Unit): TextView = TextView(this).apply {
        text = label
        gravity = Gravity.CENTER
        textSize = 15f
        setTextColor(fg)
        typeface = Typeface.DEFAULT_BOLD
        background = rounded(bg, 12)
        setPadding(dp(8), dp(10), dp(8), dp(10))
        setOnClickListener { onClick() }
    }

    private fun setupOverlay() {
        tap = TapView(this)
        mlp = WindowManager.LayoutParams(
            realW, realH, WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            if (Build.VERSION.SDK_INT >= 28) {
                layoutInDisplayCutoutMode = WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_SHORT_EDGES
            }
        }
        wm.addView(tap, mlp)

        panelBg.setColor(Color.argb(240, 18, 22, 32))
        panelBg.cornerRadius = dp(18).toFloat()
        panelBg.setStroke(dp(2), withAlpha(GREEN, 200))
        panel = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            background = panelBg
            setPadding(dp(14), dp(10), dp(14), dp(12))
        }
        panelTitle = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.argb(170, 255, 255, 255))
            setOnClickListener { flipPanel() }
        }
        panelText = TextView(this).apply {
            textSize = 16f
            setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        panelHint = TextView(this).apply {
            textSize = 12f
            setTextColor(Color.rgb(255, 193, 7))
            visibility = View.GONE
        }
        panel.addView(panelTitle)
        panel.addView(panelText, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })
        panel.addView(panelHint, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4) })

        val row = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        val dim = Color.rgb(44, 52, 68)
        fun add(v: TextView, w: Float) {
            row.addView(v, LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, w).apply {
                marginStart = dp(3); marginEnd = dp(3)
            })
        }
        add(pill("◀", dim, Color.WHITE) { go(pos - 1) }, 1f)
        add(pill("✓ Сделал", GREEN, Color.rgb(10, 25, 15)) { go(pos + 1) }, 2.4f)
        add(pill("▶", dim, Color.WHITE) { go(pos + 1) }, 1f)
        add(pill("✕", dim, Color.WHITE) { stopSelf() }, 1f)
        panel.addView(row, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(10) })

        plp = WindowManager.LayoutParams(
            minOf(realW - dp(24), dp(460)), WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCH_MODAL,
            PixelFormat.TRANSLUCENT
        ).apply {
            gravity = Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL
            y = dp(16)
        }
        wm.addView(panel, plp)
    }

    private fun flipPanel() {
        panelTop = !panelTop
        plp.gravity = (if (panelTop) Gravity.TOP else Gravity.BOTTOM) or Gravity.CENTER_HORIZONTAL
        plp.y = if (panelTop) dp(32) else dp(16)
        wm.updateViewLayout(panel, plp)
    }

    private fun setAccent(c: Int) {
        accentColor = c
        panelBg.setStroke(dp(2), withAlpha(c, 200))
    }

    private fun refreshPanel() {
        val p = plan ?: return
        val total = p.flat.size
        if (pos >= total) {
            panelTitle.text = "🎉 Существо готово"
            panelText.text = "Все шаги выполнены. Проверь организм в игре!"
            curTargets = emptyList()
            tap.hide()
            setAccent(GREEN)
        } else {
            val act = p.flat[pos]
            val st = p.steps[act.step]
            panelTitle.text = "Шаг ${act.step + 1}/${p.steps.size} · ${st.title}  (${pos + 1}/$total)"
            panelText.text = act.text
            curTargets = act.targets.map { norm(it) }.filter { it.length >= 2 }
            setAccent(cellAccent(st.cell))
        }
        panelHint.visibility = View.GONE
        panelText.alpha = 0f
        panelText.animate().alpha(1f).setDuration(220).start()
    }

    private fun go(newPos: Int) {
        val p = plan ?: return
        val np = newPos.coerceIn(0, p.flat.size)
        if (np == pos) return
        pos = np
        prefs.edit().putInt("pos", pos).apply()     // память: прогресс сохраняется
        miss = 0
        flipsLeft = 1
        lastRect = null
        tap.hide()
        refreshPanel()
    }

    // ---------- захват и поиск элемента на экране ----------
    private fun loop() {
        if (!running) return
        // прогресс мог измениться в самом приложении
        val saved = prefs.getInt("pos", pos)
        if (saved != pos && plan != null) {
            pos = saved.coerceIn(0, plan!!.flat.size)
            miss = 0; flipsLeft = 1; lastRect = null
            tap.hide()
            refreshPanel()
        }
        checkRotation()
        if (!ocrBusy) {
            val bmp = grab()
            if (bmp != null) {
                ocrBusy = true
                recognize(bmp)
            }
        }
        main.postDelayed({ loop() }, 1000)
    }

    private fun checkRotation() {
        val s = realSize()
        if (s.first == realW && s.second == realH) return
        realW = s.first
        realH = s.second
        reader?.close()
        reader = ImageReader.newInstance(realW, realH, PixelFormat.RGBA_8888, 2)
        display?.resize(realW, realH, resources.displayMetrics.densityDpi)
        display?.surface = reader!!.surface
        mlp.width = realW
        mlp.height = realH
        wm.updateViewLayout(tap, mlp)
        plp.width = minOf(realW - dp(24), dp(460))
        wm.updateViewLayout(panel, plp)
        lastRect = null
        tap.hide()
    }

    private fun grab(): Bitmap? {
        val img = reader?.acquireLatestImage() ?: return null
        img.use {
            val p = it.planes[0]
            val rowPad = p.rowStride - p.pixelStride * it.width
            val full = Bitmap.createBitmap(it.width + rowPad / p.pixelStride, it.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(p.buffer)
            return Bitmap.createBitmap(full, 0, 0, it.width, it.height)
        }
    }

    private fun panelRect(): Rect? {
        if (panel.width == 0) return null
        val loc = IntArray(2)
        panel.getLocationOnScreen(loc)
        return Rect(loc[0], loc[1], loc[0] + panel.width, loc[1] + panel.height)
    }

    private fun recognize(bmp: Bitmap) {
        recognizer.process(InputImage.fromBitmap(bmp, 0))
            .addOnSuccessListener { r ->
                val pr = panelRect()
                val list = ArrayList<Line>()
                for (b in r.textBlocks) {
                    for (l in b.lines) {
                        val box = l.boundingBox ?: continue
                        if (pr != null && Rect.intersects(box, pr)) continue   // не читаем собственную панель
                        list.add(Line(l.text, box, norm(l.text)))
                    }
                }
                lines = list
                updateTarget()
            }
            .addOnCompleteListener {
                bmp.recycle()
                ocrBusy = false
            }
    }

    private fun lev(a: String, b: String): Int {
        var prev = IntArray(b.length + 1) { it }
        var cur = IntArray(b.length + 1)
        for (i in 1..a.length) {
            cur[0] = i
            for (j in 1..b.length) {
                val cost = if (a[i - 1] == b[j - 1]) 0 else 1
                cur[j] = minOf(prev[j] + 1, cur[j - 1] + 1, prev[j - 1] + cost)
            }
            val tmp = prev; prev = cur; cur = tmp
        }
        return prev[b.length]
    }

    private fun score(a: String, t: String): Int {
        if (a == t) return 3
        if (a.length >= 4 && t.length >= 4) {
            val mx = maxOf(a.length, t.length)
            if (abs(a.length - t.length) <= mx / 4 && lev(a, t) <= mx / 5) return 2
            if (a.contains(t) || t.contains(a)) return 1
        }
        return 0
    }

    private fun updateTarget() {
        val p = plan ?: return
        val act = p.flat.getOrNull(pos)
        if (act == null || curTargets.isEmpty()) {
            tap.hide()
            panelHint.visibility = View.GONE
            return
        }
        var best: Line? = null
        var bestScore = 0
        var bestD = Float.MAX_VALUE
        for (l in lines) {
            var sc = 0
            for (t in curTargets) sc = maxOf(sc, score(l.n, t))
            if (sc == 0) continue
            val ref = lastRect
            val dd = if (ref != null) abs(l.box.centerY() - ref.centerY()) else 0f
            if (sc > bestScore || (sc == bestScore && dd < bestD)) {
                best = l; bestScore = sc; bestD = dd
            }
        }
        if (best != null) {
            miss = 0
            val rect = RectF(best.box)
            lastRect = rect
            panelHint.visibility = View.GONE
            tap.show(rect, accentColor)
        } else {
            miss++
            if (miss >= 3) {
                tap.hide()
                panelHint.text = "Не вижу «${act.targets.first()}» на экране — открой нужный раздел редактора"
                panelHint.visibility = View.VISIBLE
                // возможно, элемент закрыт самой панелью — один раз переносим её
                if (miss % 3 == 0 && flipsLeft > 0) {
                    flipsLeft--
                    flipPanel()
                }
            }
        }
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        try { wm.removeView(tap) } catch (e: Exception) {}
        try { wm.removeView(panel) } catch (e: Exception) {}
        display?.release(); reader?.close(); projection?.stop()
        super.onDestroy()
    }
}
