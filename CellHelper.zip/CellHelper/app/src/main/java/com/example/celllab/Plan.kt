package com.example.celllab

import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONObject

/** Одно действие: что сделать и какую надпись на экране игры подсветить. */
class Act(val step: Int, val text: String, val targets: List<String>)
class Step(val title: String, val cell: String, val acts: List<Act>)

class Plan(val name: String, val idea: String, val steps: List<Step>, val tips: List<String>) {
    val flat: List<Act> = steps.flatMap { it.acts }
    fun firstPosOfStep(i: Int): Int {
        var n = 0
        for (k in 0 until i.coerceAtMost(steps.size)) n += steps[k].acts.size
        return n
    }
}

fun cellAccent(cell: String): Int {
    val c = cell.lowercase()
    return when {
        "phago" in c -> Color.rgb(255, 167, 38)
        "flagel" in c -> Color.rgb(66, 165, 245)
        "photo" in c -> Color.rgb(102, 187, 106)
        "devor" in c -> Color.rgb(239, 83, 80)
        "lipo" in c -> Color.rgb(255, 238, 88)
        "kerat" in c -> Color.rgb(161, 136, 127)
        "buoy" in c -> Color.rgb(128, 222, 234)
        "glue" in c -> Color.rgb(186, 104, 200)
        "viro" in c -> Color.rgb(212, 225, 87)
        "nitro" in c -> Color.rgb(255, 112, 67)
        "stem" in c -> Color.rgb(189, 189, 189)
        "sense" in c -> Color.rgb(77, 208, 225)
        "myo" in c -> Color.rgb(240, 98, 146)
        "neuro" in c -> Color.rgb(149, 117, 205)
        "secro" in c -> Color.rgb(174, 213, 129)
        "stereo" in c -> Color.rgb(144, 164, 174)
        else -> Color.rgb(46, 204, 113)
    }
}

object PlanStore {
    fun parseObj(raw: String): JSONObject? {
        val s = raw.indexOf('{')
        val e = raw.lastIndexOf('}')
        if (s < 0 || e <= s) return null
        return try { JSONObject(raw.substring(s, e + 1)) } catch (ex: Exception) { null }
    }

    fun parse(raw: String): Plan? {
        val o = parseObj(raw) ?: return null
        val arr = o.optJSONArray("steps") ?: return null
        val steps = ArrayList<Step>()
        for (i in 0 until arr.length()) {
            val so = arr.optJSONObject(i) ?: continue
            val idx = steps.size
            val acts = ArrayList<Act>()
            val aa = so.optJSONArray("actions")
            if (aa != null) {
                for (k in 0 until aa.length()) {
                    val item = aa.opt(k)
                    if (item is JSONObject) {
                        val targets = ArrayList<String>()
                        val t = item.optString("target", "").trim()
                        if (t.isNotEmpty()) targets.add(t)
                        val alt = item.optJSONArray("alt")
                        if (alt != null) {
                            for (j in 0 until alt.length()) {
                                val s = alt.optString(j).trim()
                                if (s.isNotEmpty()) targets.add(s)
                            }
                        }
                        acts.add(Act(idx, item.optString("text", "").trim(), targets))
                    } else if (item is String) {
                        acts.add(Act(idx, item.trim(), emptyList()))
                    }
                }
            }
            val title = so.optString("title", "Шаг ${idx + 1}")
            if (acts.isEmpty()) acts.add(Act(idx, title, emptyList()))
            steps.add(Step(title, so.optString("cell", ""), acts))
        }
        if (steps.isEmpty()) return null
        val tips = ArrayList<String>()
        val ta = o.optJSONArray("tips")
        if (ta != null) for (k in 0 until ta.length()) tips.add(ta.optString(k))
        return Plan(o.optString("name", "Существо"), o.optString("idea", ""), steps, tips)
    }

    fun load(p: SharedPreferences): Plan? {
        val raw = p.getString("plan", null) ?: return null
        return parse(raw)
    }
}
