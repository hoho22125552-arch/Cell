package com.example.celllab

import android.animation.Animator
import android.animation.AnimatorListenerAdapter
import android.animation.ValueAnimator
import android.content.Context
import android.graphics.*
import android.view.View
import android.view.animation.DecelerateInterpolator
import android.view.animation.LinearInterpolator
import android.view.animation.OvershootInterpolator
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.sin

/** Подсветка элемента, на который нужно нажать: рамка, расходящиеся волны и прыгающая стрелка. */
class TapView(ctx: Context) : View(ctx) {
    private val d = resources.displayMetrics.density
    private var color = Color.rgb(46, 204, 113)

    private val strokeP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 3 * d }
    private val glowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE }
    private val fillP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val ringP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2 * d }
    private val arrowP = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.FILL }
    private val arrowOutlineP = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2 * d; strokeJoin = Paint.Join.ROUND
    }

    private var from: RectF? = null
    private var to: RectF? = null
    private var morph = 1f
    private var shown = false
    private var appear = 0f
    private var t = 0f
    private var appearAnim: ValueAnimator? = null
    private var morphAnim: ValueAnimator? = null

    private val loopAnim: ValueAnimator = ValueAnimator.ofFloat(0f, 1f).apply {
        duration = 1400
        repeatCount = ValueAnimator.INFINITE
        interpolator = LinearInterpolator()
        addUpdateListener { t = it.animatedValue as Float; invalidate() }
    }

    private fun withAlpha(c: Int, a: Int): Int =
        Color.argb(a.coerceIn(0, 255), Color.red(c), Color.green(c), Color.blue(c))

    private fun current(): RectF? {
        val a = from ?: return to
        val b = to ?: return null
        return RectF(
            a.left + (b.left - a.left) * morph, a.top + (b.top - a.top) * morph,
            a.right + (b.right - a.right) * morph, a.bottom + (b.bottom - a.bottom) * morph
        )
    }

    private fun differs(a: RectF, b: RectF): Boolean =
        abs(a.left - b.left) > 3 || abs(a.top - b.top) > 3 || abs(a.right - b.right) > 3 || abs(a.bottom - b.bottom) > 3

    fun show(r: RectF, tone: Int) {
        color = tone
        val wasHidden = !shown
        shown = true
        val cur = current()
        if (wasHidden || cur == null) {
            morphAnim?.cancel()
            from = RectF(r); to = RectF(r); morph = 1f
        } else if (differs(cur, r)) {
            morphAnim?.cancel()
            from = cur; to = RectF(r); morph = 0f
            morphAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 260
                interpolator = DecelerateInterpolator()
                addUpdateListener { morph = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (wasHidden) {
            appearAnim?.cancel()
            appearAnim = ValueAnimator.ofFloat(0f, 1f).apply {
                duration = 550
                interpolator = OvershootInterpolator(1.4f)
                addUpdateListener { appear = it.animatedValue as Float; invalidate() }
                start()
            }
        }
        if (!loopAnim.isRunning) loopAnim.start()
        invalidate()
    }

    fun hide() {
        if (!shown) return
        shown = false
        appearAnim?.cancel()
        appearAnim = ValueAnimator.ofFloat(appear, 0f).apply {
            duration = 220
            addUpdateListener { appear = it.animatedValue as Float; invalidate() }
            addListener(object : AnimatorListenerAdapter() {
                override fun onAnimationEnd(animation: Animator) {
                    if (!shown) {
                        loopAnim.cancel()
                        from = null; to = null; appear = 0f
                        invalidate()
                    }
                }
            })
            start()
        }
    }

    override fun onDraw(canvas: Canvas) {
        val r = current() ?: return
        if (appear <= 0f) return
        val a = appear.coerceIn(0f, 1f)
        val pulse = 0.5f + 0.5f * sin(2.0 * PI * t).toFloat()

        val cx0 = r.centerX()
        val cy0 = r.centerY()
        val w = max(r.width() + 16 * d, 56 * d)
        val h = max(r.height() + 8 * d, 40 * d)
        val box = RectF(cx0 - w / 2, cy0 - h / 2, cx0 + w / 2, cy0 + h / 2)
        val rad = 12 * d

        canvas.save()
        canvas.scale(appear, appear, cx0, cy0)

        fillP.shader = LinearGradient(
            0f, box.top, 0f, box.bottom,
            withAlpha(color, (60 * a).toInt()), withAlpha(color, (15 * a).toInt()), Shader.TileMode.CLAMP
        )
        canvas.drawRoundRect(box, rad, rad, fillP)

        // расходящиеся волны
        for (k in 0..1) {
            val ph = (t + k * 0.5f) % 1f
            val grow = ph * 20 * d
            val rb = RectF(box.left - grow, box.top - grow, box.right + grow, box.bottom + grow)
            ringP.color = withAlpha(color, ((1f - ph) * 190 * a).toInt())
            canvas.drawRoundRect(rb, rad + grow, rad + grow, ringP)
        }

        glowP.strokeWidth = (6 + 6 * pulse) * d
        glowP.color = withAlpha(color, ((40 + 90 * pulse) * a).toInt())
        canvas.drawRoundRect(box, rad, rad, glowP)
        strokeP.color = withAlpha(color, (255 * a).toInt())
        canvas.drawRoundRect(box, rad, rad, strokeP)

        // прыгающая стрелка
        val above = box.top > 100 * d
        val s = if (above) -1f else 1f
        val bounce = (0.5f + 0.5f * sin(2.0 * PI * t * 2).toFloat()) * 10 * d
        val tipY = if (above) box.top - 6 * d - bounce else box.bottom + 6 * d + bounce
        val path = Path().apply {
            moveTo(cx0, tipY)
            lineTo(cx0 - 14 * d, tipY + s * 22 * d)
            lineTo(cx0 - 5 * d, tipY + s * 22 * d)
            lineTo(cx0 - 5 * d, tipY + s * 42 * d)
            lineTo(cx0 + 5 * d, tipY + s * 42 * d)
            lineTo(cx0 + 5 * d, tipY + s * 22 * d)
            lineTo(cx0 + 14 * d, tipY + s * 22 * d)
            close()
        }
        arrowP.color = withAlpha(color, (255 * a).toInt())
        canvas.drawPath(path, arrowP)
        arrowOutlineP.color = Color.argb((170 * a).toInt(), 0, 0, 0)
        canvas.drawPath(path, arrowOutlineP)

        canvas.restore()
    }
}
